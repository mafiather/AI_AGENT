@echo off
chcp 65001
cd /d "%~dp0"
echo ========开启执行调CLAUDECODELLM接口 ========
python main.py
echo.
echo ======== 开启自动生成文章========
python CODE\CODE.py
echo.
echo ========开启轮询发布公众号文章====================
python publish_wechat.py --schedule
echo.
