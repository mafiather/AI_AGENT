#!/usr/bin/env python3
"""
微信公众号文章发布工具
用法:
  python publish_wechat.py                        # 处理 OUTPUT_DIR 中所有HTML文件，生成草稿
  python publish_wechat.py --schedule             # 定时任务模式：每分钟扫描 OUTPUT_DIR 并生成草稿
  python publish_wechat.py --status               # 查看处理状态
  python publish_wechat.py <HTML文件路径> [封面图]  # 处理单个文件（兼容旧用法）

完整流程:
  1. 获取/刷新 access_token（自动缓存，2小时有效）
  2. 解析HTML，提取文内<img>标签，逐张上传到微信并替换URL
  3. 处理封面图（上传或生成默认封面）
  4. 创建草稿
  5. 记录已处理文件，避免重复生成

依赖: pip install requests pillow
"""

import json
import os
import re
import sys
import time
import requests
from pathlib import Path
from html.parser import HTMLParser

# Fix Windows console encoding for emoji and special Unicode
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# ============================================================
# 配置加载
# ============================================================
SCRIPT_DIR = Path(__file__).parent
CONFIG_FILE = SCRIPT_DIR / "config.json"

def load_config():
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

cfg = load_config()

# ============================================================
# 路径配置
# ============================================================
_raw_output = cfg.get("output_dir", str(SCRIPT_DIR.parent / "OUTPUT"))
OUTPUT_DIR = (SCRIPT_DIR / _raw_output).resolve() if not os.path.isabs(_raw_output) else Path(_raw_output).resolve()
PROCESSED_CACHE_FILE = SCRIPT_DIR / cfg.get("processed_cache_file", "drafted_files.json")
DEFAULT_COVER_FILE = SCRIPT_DIR / cfg.get("default_cover_file", "default_cover.png")

# ============================================================
# API 基础
# ============================================================
API_BASE = "https://api.weixin.qq.com"

def api_get(path, params=None):
    """GET 请求封装"""
    url = f"{API_BASE}{path}"
    resp = requests.get(url, params=params, timeout=30)
    return resp.json()

def api_post(path, data=None, files=None, params=None):
    """POST 请求封装（JSON / multipart 自动切换）

    关键：使用 ensure_ascii=False + 手动 encode 防止中文被转义为 \\uXXXX，
    否则标题长度会暴增 6 倍，触发微信 45003 错误。
    """
    url = f"{API_BASE}{path}"
    if files:
        resp = requests.post(url, params=params, data=data, files=files, timeout=60)
    else:
        json_bytes = json.dumps(data, ensure_ascii=False).encode('utf-8')
        resp = requests.post(url, params=params, data=json_bytes,
                           headers={'Content-Type': 'application/json; charset=utf-8'}, timeout=30)
    return resp.json()

# ============================================================
# ① Access Token 管理（自动缓存）
# ============================================================
def get_access_token():
    """获取 access_token，优先从缓存读取（避免频繁调用）"""
    cache_file = SCRIPT_DIR / cfg["token_cache_file"]

    # 尝试从缓存加载
    if cache_file.exists():
        with open(cache_file, "r") as f:
            cache = json.load(f)
        if cache.get("expires_at", 0) > time.time() + 120:  # 预留2分钟缓冲
            print(f"[OK] 使用缓存的 access_token（有效期至 {time.strftime('%H:%M:%S', time.localtime(cache['expires_at']))}）")
            return cache["access_token"]

    # 重新获取
    print("[*] 正在获取新的 access_token ...")
    result = api_get("/cgi-bin/token", params={
        "grant_type": "client_credential",
        "appid": cfg["appid"],
        "secret": cfg["appsecret"],
    })

    if "access_token" not in result:
        raise RuntimeError(f"获取 access_token 失败: {result}")

    # 写入缓存
    access_token = result["access_token"]
    cache = {
        "access_token": access_token,
        "expires_at": time.time() + result.get("expires_in", 7200),
    }
    with open(cache_file, "w") as f:
        json.dump(cache, f)

    print(f"[OK] access_token 获取成功")
    return access_token


# ============================================================
# ② 图片处理 —— 上传文内图片到微信
# ============================================================
def upload_content_image(access_token, image_path):
    """
    上传图文消息内的图片（不占用素材库容量）
    返回微信域内的 URL（可用于 <img src="...">）
    仅支持 jpg/png，大小 ≤1MB
    """
    url = f"{API_BASE}/cgi-bin/media/uploadimg"
    with open(image_path, "rb") as f:
        files = {"media": (os.path.basename(image_path), f, "image/jpeg")}
        resp = requests.post(url, params={"access_token": access_token}, files=files, timeout=30)
    result = resp.json()
    if "url" in result:
        return result["url"]
    raise RuntimeError(f"上传图片失败: {result}")

def is_external_image(src):
    """判断图片是否为外部URL（非微信域）"""
    return not src.startswith("https://mmbiz.") and not src.startswith("http://mmbiz.")

def is_local_image(src):
    """判断是否为本地文件路径"""
    return not src.startswith("http://") and not src.startswith("https://") and not src.startswith("data:")

def process_images_in_html(access_token, html_content, base_dir):
    """
    解析HTML中的 <img> 标签，将本地图片上传到微信并替换 src。
    返回 (处理后的HTML, 第一张本地图片的路径) 供封面图候选。
    """
    class ImageExtractor(HTMLParser):
        def __init__(self):
            super().__init__()
            self.images = []
            self._current_tag = None
            self._current_attrs = None

        def handle_starttag(self, tag, attrs):
            if tag == "img":
                self.images.append(dict(attrs))

    parser = ImageExtractor()
    parser.feed(html_content)
    parser.close()

    first_local_img = None
    replaced = html_content

    for i, img in enumerate(parser.images):
        src = img.get("src", "")
        if not src:
            continue

        # 处理本地文件
        if is_local_image(src):
            local_path = Path(base_dir) / src
            if not local_path.exists():
                local_path = Path(src)  # 尝试绝对路径
            if local_path.exists():
                if first_local_img is None:
                    first_local_img = str(local_path)
                print(f"[*] 上传文中图片 ({i+1}/{len(parser.images)}): {local_path.name}")
                new_url = upload_content_image(access_token, str(local_path))
                replaced = replaced.replace(f'src="{src}"', f'src="{new_url}"', 1)
                replaced = replaced.replace(f"src='{src}'", f"src='{new_url}'", 1)
                print(f"    -> {new_url}")
            else:
                print(f"[WARN] 图片未找到，跳过: {src}")
        else:
            # 外部URL（需要在公众号后台"图片水印/防盗链"中设置白名单）
            if first_local_img is None and not src.startswith("https://mmbiz."):
                first_local_img = src  # 标记为外部图片
            print(f"[INFO] 外部图片保留原URL: {src[:80]}...")

    return replaced, first_local_img

# ============================================================
# ③ 上传封面图为永久素材 & 默认封面生成
# ============================================================
def upload_cover_material(access_token, image_path):
    """
    上传封面图到永久素材库，返回 media_id
    封面图要求：jpg/png，建议 900x500 像素
    """
    print(f"[*] 上传封面图: {image_path}")
    url = f"{API_BASE}/cgi-bin/material/add_material"
    ext = os.path.splitext(str(image_path))[1].lower()
    mime_map = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif'}
    mime_type = mime_map.get(ext, 'image/jpeg')
    with open(image_path, "rb") as f:
        files = {"media": (os.path.basename(image_path), f, mime_type)}
        resp = requests.post(url,
                             params={"access_token": access_token, "type": "image"},
                             files=files,
                             timeout=30)
    result = resp.json()
    if "media_id" in result:
        print(f"[OK] 封面图 media_id: {result['media_id']}")
        return result["media_id"]
    raise RuntimeError(f"上传封面图失败: {result}")

def generate_default_cover(title="", output_path=None):
    """
    使用 Pillow 生成默认封面图（900x500 渐变背景 + 标题文字）。
    如果 Pillow 不可用，创建一个最小的纯色 PNG。
    """
    if output_path is None:
        output_path = DEFAULT_COVER_FILE

    if output_path.exists():
        print(f"[INFO] 默认封面已存在: {output_path}")
        return str(output_path)

    try:
        from PIL import Image, ImageDraw, ImageFont

        width, height = 900, 500
        img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # 渐变背景：深蓝 → 深紫
        for y in range(height):
            r = int(26 + (y / height) * 30)
            g = int(26 + (y / height) * 10)
            b = int(46 + (y / height) * 50)
            draw.line([(0, y), (width, y)], fill=(r, g, b, 255))

        # 装饰圆
        draw.ellipse([650, -100, 950, 200], fill=(212, 56, 13, 40))
        draw.ellipse([-50, 350, 250, 600], fill=(24, 144, 255, 30))

        # 标题文字
        if title:
            font = None
            font_size = 36
            font_candidates = [
                "C:/Windows/Fonts/msyh.ttc",
                "C:/Windows/Fonts/msyhbd.ttc",
                "C:/Windows/Fonts/simhei.ttf",
                "C:/Windows/Fonts/simsun.ttc",
            ]
            for fp in font_candidates:
                if os.path.exists(fp):
                    try:
                        font = ImageFont.truetype(fp, font_size)
                        break
                    except Exception:
                        continue

            if font is None:
                font = ImageFont.load_default()

            # 文字换行与居中
            max_width = width - 120
            lines = []
            current_line = ""
            for char in title:
                test_line = current_line + char
                bbox = draw.textbbox((0, 0), test_line, font=font)
                if bbox[2] - bbox[0] > max_width and current_line:
                    lines.append(current_line)
                    current_line = char
                else:
                    current_line = test_line
            if current_line:
                lines.append(current_line)

            total_text_height = len(lines) * (font_size + 10) - 10
            y_start = (height - total_text_height) // 2

            for i, line in enumerate(lines):
                bbox = draw.textbbox((0, 0), line, font=font)
                text_width = bbox[2] - bbox[0]
                x = (width - text_width) // 2
                y = y_start + i * (font_size + 10)
                # 文字阴影
                draw.text((x + 2, y + 2), line, font=font, fill=(0, 0, 0, 100))
                # 文字主体
                draw.text((x, y), line, font=font, fill=(255, 255, 255, 240))

        img.save(output_path, "PNG")
        print(f"[OK] 默认封面已生成: {output_path}")
        return str(output_path)

    except ImportError:
        print("[WARN] Pillow 未安装，生成最小默认封面...")
        return _generate_minimal_png(output_path)

def _generate_minimal_png(output_path):
    """纯 Python 生成最小的 900x500 PNG（纯色，无文字）"""
    import struct
    import zlib

    width, height = 900, 500
    r, g, b = 26, 26, 46

    def make_chunk(chunk_type, data):
        chunk = chunk_type + data
        crc = struct.pack(">I", zlib.crc32(chunk) & 0xffffffff)
        return struct.pack(">I", len(data)) + chunk + crc

    signature = b'\x89PNG\r\n\x1a\n'

    ihdr_data = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    ihdr = make_chunk(b'IHDR', ihdr_data)

    raw_data = b''
    for y in range(height):
        raw_data += b'\x00'
        for x in range(width):
            raw_data += struct.pack("BBB", r, g, b)

    idat = make_chunk(b'IDAT', zlib.compress(raw_data))

    iend = make_chunk(b'IEND', b'')

    with open(output_path, 'wb') as f:
        f.write(signature + ihdr + idat + iend)

    print(f"[OK] 最小默认封面已生成: {output_path}")
    return str(output_path)

def download_external_image(url, output_path):
    """下载外部图片到本地，自动检测文件类型。不支持 SVG/非图片格式时返回 None。"""
    try:
        resp = requests.get(url, timeout=30, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        if resp.status_code == 200:
            content_type = resp.headers.get('Content-Type', '')

            # 微信不支持 SVG
            if 'svg' in content_type or 'xml' in content_type:
                print(f"[WARN] 不支持的图片格式 ({content_type})，跳过: {url[:60]}...")
                return None

            # 根据 Content-Type 确定扩展名
            ext_map = {
                'image/png': '.png',
                'image/jpeg': '.jpg',
                'image/jpg': '.jpg',
                'image/gif': '.gif',
                'image/webp': '.webp',
            }
            ext = '.jpg'
            for mime, suffix in ext_map.items():
                if mime in content_type:
                    ext = suffix
                    break

            # 调整输出路径的扩展名
            output_path = Path(output_path)
            output_path = output_path.with_suffix(ext)

            with open(output_path, 'wb') as f:
                f.write(resp.content)
            print(f"[OK] 下载外部图片: {url[:60]}... -> {output_path} (type: {content_type})")
            return str(output_path)
    except Exception as e:
        print(f"[WARN] 下载外部图片失败: {e}")
    return None

# ============================================================
# 辅助：提取文章正文
# ============================================================
def extract_article_content(html_content):
    """
    从完整 HTML 中提取文章正文。
    - 提取 <body> 内部内容
    - 移除 <script> 标签（微信不允许 JS）
    - 保留 <style> 和内联样式（微信支持）
    - 如果无 <body>，返回原内容
    """
    m = re.search(r"<body[^>]*>(.*?)</body>", html_content, re.DOTALL | re.IGNORECASE)
    if m:
        content = m.group(1)
        print(f"[INFO] 提取 body 内容: {len(content)} 字符")
    else:
        content = html_content

    content = re.sub(r"<script[^>]*>.*?</script>", "", content, flags=re.DOTALL | re.IGNORECASE)

    return content.strip()

def extract_plain_text(html_content):
    """
    从 HTML 中提取纯文本（用于摘要生成）。
    """
    text = re.sub(r"<(style|script)[^>]*>.*?</\1>", "", html_content, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    text = text.replace("&quot;", "\"").replace("&#39;", "'")
    text = re.sub(r"\s+", " ", text).strip()
    return text

def extract_title_from_html(html_content):
    """从 HTML <title> 或 <h1> 中提取标题（限制长度≤32字符）"""
    m = re.search(r"<title>(.+?)</title>", html_content, re.IGNORECASE)
    if m:
        title = m.group(1).strip()
        return title[:32] if len(title) > 32 else title
    m = re.search(r'<h1[^>]*id="activity-name"[^>]*>(.+?)</h1>', html_content)
    if m:
        title = re.sub(r"<[^>]+>", "", m.group(1)).strip()
        return title[:32] if len(title) > 32 else title
    m = re.search(r"<h1[^>]*>(.+?)</h1>", html_content, re.IGNORECASE)
    if m:
        title = re.sub(r"<[^>]+>", "", m.group(1)).strip()
        return title[:32] if len(title) > 32 else title
    return "未命名文章"

# ============================================================
# ④ 创建草稿
# ============================================================
def create_draft(access_token, title, content, thumb_media_id, author=None,
                 digest=None, content_source_url="", need_open_comment=1,
                 only_fans_can_comment=0):
    """
    创建草稿，返回草稿的 media_id
    """
    if author is None:
        author = cfg.get("author", "")
    if len(author) > 8:
        print(f"[WARN] 作者名超 8 字符，自动截断: [{author}] -> [{author[:8]}]")
        author = author[:8]
    if digest is None:
        plain = extract_plain_text(content)
        digest = plain[:120]

    print(f"[*] 创建草稿...")
    print(f"    标题: {title}")
    print(f"    作者: {author}")
    print(f"    摘要: {digest[:60]}...")
    print(f"    正文长度: {len(content)} 字符")

    article = {
        "title": title,
        "thumb_media_id": thumb_media_id,
        "author": author,
        "digest": digest,
        "show_cover_pic": 1,
        "content": content,
        "content_source_url": content_source_url,
        "need_open_comment": need_open_comment,
        "only_fans_can_comment": only_fans_can_comment,
        "need_open_reward": 0,
    }

    result = api_post("/cgi-bin/draft/add", data={"articles": [article]},
                      params={"access_token": access_token})

    if "media_id" in result:
        draft_id = result["media_id"]
        print(f"[OK] 草稿创建成功！media_id: {draft_id}")
        return draft_id
    raise RuntimeError(f"创建草稿失败: {result}")

# ============================================================
# ⑤ 发布草稿
# ============================================================
def publish_draft(access_token, media_id):
    """
    发布草稿（通过「发布」能力，非群发，不占用群发次数）
    """
    print(f"[*] 正在发布草稿 {media_id} ...")
    result = api_post("/cgi-bin/freepublish/submit",
                      data={"media_id": media_id},
                      params={"access_token": access_token})

    if "publish_id" in result:
        publish_id = result["publish_id"]
        print(f"[OK] 发布成功！publish_id: {publish_id}")
        if "msg_data_id" in result:
            print(f"    msg_data_id: {result['msg_data_id']}")
        return result
    raise RuntimeError(f"发布失败: {result}")

# ============================================================
# 已处理文件追踪（避免重复生成草稿）
# ============================================================
def load_processed_files():
    """加载已处理的文件记录，返回 {filename: {status, media_id, time}}"""
    if PROCESSED_CACHE_FILE.exists():
        with open(PROCESSED_CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_processed_file(filename, status, media_id=None):
    """记录一个文件已处理"""
    records = load_processed_files()
    records[filename] = {
        "status": status,
        "media_id": media_id,
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with open(PROCESSED_CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)

def is_file_processed(filename):
    """检查文件是否已成功处理"""
    records = load_processed_files()
    return filename in records and records[filename].get("status") == "drafted"

# ============================================================
# 扫描 OUTPUT 目录
# ============================================================
def scan_output_dir():
    """扫描 OUTPUT_DIR 中的所有 HTML 文件，返回排序后的路径列表"""
    if not OUTPUT_DIR.exists():
        print(f"[WARN] OUTPUT 目录不存在: {OUTPUT_DIR}")
        return []
    html_files = sorted(OUTPUT_DIR.glob("*.html"))
    print(f"[INFO] 在 {OUTPUT_DIR} 中发现 {len(html_files)} 个 HTML 文件")
    return html_files

# ============================================================
# 处理单个 HTML 文件（完整流水线）
# ============================================================
def process_single_file(html_path, access_token, cover_path=None):
    """
    处理单个 HTML 文件：提取内容 → 处理图片 → 上传封面 → 创建草稿
    返回 (success: bool, media_id: str|None, error: str|None)
    """
    filename = html_path.name
    print(f"\n{'─' * 60}")
    print(f"  处理文件: {filename}")
    print(f"{'─' * 60}")

    try:
        # Step 0: 读取 HTML
        with open(html_path, "r", encoding="utf-8") as f:
            raw_html = f.read()

        title = extract_title_from_html(raw_html)
        print(f"  文章标题: {title}")

        # 提取文章正文
        html_content = extract_article_content(raw_html)

        # Step 1: 处理文内图片
        html_content, first_image = process_images_in_html(
            access_token, html_content, str(html_path.parent)
        )

        # Step 2: 处理封面图（多种来源尝试，最终回退到默认封面）
        thumb_media_id = None

        def try_upload_cover(img_path, source_desc):
            """尝试上传封面，失败时返回 None（不抛异常）"""
            try:
                return upload_cover_material(access_token, img_path)
            except Exception as e:
                print(f"[WARN] {source_desc}上传失败: {e}")
                return None

        def fallback_to_default():
            """使用默认封面"""
            print("[INFO] 使用默认封面")
            default_cover = generate_default_cover(title)
            return upload_cover_material(access_token, default_cover)

        if cover_path and Path(cover_path).exists():
            thumb_media_id = try_upload_cover(str(cover_path), "指定封面")

        if thumb_media_id is None and first_image:
            if is_local_image(first_image) and Path(first_image).exists():
                print(f"[INFO] 使用文中第一张图片作为封面")
                thumb_media_id = try_upload_cover(first_image, "文中图片")
            elif first_image.startswith("http"):
                print(f"[INFO] 尝试下载外部图片作为封面: {first_image[:80]}...")
                temp_cover = SCRIPT_DIR / f"_temp_cover_{html_path.stem}.jpg"
                downloaded = download_external_image(first_image, temp_cover)
                if downloaded:
                    thumb_media_id = try_upload_cover(downloaded, "外部图片")
                    # 清理临时文件
                    try:
                        if Path(downloaded).exists():
                            Path(downloaded).unlink()
                    except Exception:
                        pass
                if thumb_media_id is None:
                    print("[INFO] 外部图片不可用，回退到默认封面")

        if thumb_media_id is None:
            thumb_media_id = fallback_to_default()

        # Step 3: 创建草稿
        draft_media_id = create_draft(
            access_token=access_token,
            title=title,
            content=html_content,
            thumb_media_id=thumb_media_id,
        )

        # 记录成功
        save_processed_file(filename, "drafted", draft_media_id)
        print(f"\n[OK] {filename} → 草稿创建成功 (media_id: {draft_media_id})")
        return True, draft_media_id, None

    except Exception as e:
        error_msg = str(e)
        print(f"\n[FAIL] {filename} 处理失败: {error_msg}")
        save_processed_file(filename, "failed", None)
        return False, None, error_msg

# ============================================================
# 批量处理 OUTPUT 目录中的所有 HTML 文件
# ============================================================
def process_all_files(access_token=None, force=False):
    """
    处理 OUTPUT_DIR 中的所有 HTML 文件。
    force=True 时重新处理已处理过的文件。
    返回 (total, success, failed) 计数。
    """
    if access_token is None:
        access_token = get_access_token()

    html_files = scan_output_dir()
    if not html_files:
        print("[INFO] 没有找到 HTML 文件，无需处理")
        return 0, 0, 0

    total = len(html_files)
    success_count = 0
    failed_count = 0
    skipped_count = 0

    for html_path in html_files:
        filename = html_path.name

        if not force and is_file_processed(filename):
            print(f"[SKIP] {filename} 已处理过，跳过（使用 --force 强制重新处理）")
            skipped_count += 1
            continue

        ok, media_id, error = process_single_file(html_path, access_token)
        if ok:
            success_count += 1

            if cfg.get("auto_publish", False):
                try:
                    print(f"[*] 自动发布草稿 {media_id} ...")
                    publish_draft(access_token, media_id)
                except Exception as e:
                    print(f"[WARN] 发布失败: {e}")
        else:
            failed_count += 1

    print(f"\n{'=' * 60}")
    print(f"  处理完成: 总计 {total} | 成功 {success_count} | 失败 {failed_count} | 跳过 {skipped_count}")
    print(f"{'=' * 60}")

    return total, success_count, failed_count

# ============================================================
# 定时任务模式 (SCHEDULE_DRAFT)
# ============================================================
def run_schedule(interval=300):
    """
    定时任务模式：每 `interval` 秒扫描 OUTPUT_DIR 并处理新文件。
    任务名称: SCHEDULE_DRAFT
    """
    print(f"\n{'=' * 60}")
    print(f"  SCHEDULE_DRAFT 定时任务已启动")
    print(f"  扫描目录: {OUTPUT_DIR}")
    print(f"  扫描间隔: {interval} 秒")
    print(f"  启动时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  按 Ctrl+C 停止")
    print(f"{'=' * 60}\n")

    try:
        access_token = get_access_token()
    except Exception as e:
        print(f"[ERROR] 获取 access_token 失败: {e}")
        print("[WARN] 将在下次扫描时重试...")
        access_token = None

    iteration = 0
    while True:
        iteration += 1
        print(f"\n[SCHEDULE_DRAFT] 第 {iteration} 次扫描 — {time.strftime('%Y-%m-%d %H:%M:%S')}")

        try:
            if access_token is None:
                access_token = get_access_token()
            else:
                cache_file = SCRIPT_DIR / cfg["token_cache_file"]
                if cache_file.exists():
                    with open(cache_file, "r") as f:
                        cache = json.load(f)
                    if cache.get("expires_at", 0) <= time.time() + 120:
                        print("[*] access_token 即将过期，刷新中...")
                        access_token = get_access_token()

            process_all_files(access_token=access_token)

        except Exception as e:
            print(f"[ERROR] 扫描出错: {e}")
            access_token = None

        print(f"[SCHEDULE_DRAFT] 等待 {interval} 秒后进行下一次扫描...")
        time.sleep(interval)


# ============================================================
# 显示状态
# ============================================================
def show_status():
    """显示当前处理状态"""
    records = load_processed_files()
    html_files = scan_output_dir()

    print(f"\n{'=' * 60}")
    print(f"  处理状态")
    print(f"{'=' * 60}")
    print(f"  OUTPUT 目录: {OUTPUT_DIR}")
    print(f"  HTML 文件总数: {len(html_files)}")
    print(f"  已处理文件数: {len(records)}")
    print()

    drafted = [(f, r) for f, r in records.items() if r.get("status") == "drafted"]
    failed = [(f, r) for f, r in records.items() if r.get("status") == "failed"]
    pending = [f for f in html_files if f.name not in records]

    print(f"  OK 已生成草稿: {len(drafted)}")
    for fname, r in drafted:
        print(f"     - {fname}  (media_id: {r.get('media_id', 'N/A')})  ({r.get('time', 'N/A')})")

    print(f"  FAIL 处理失败: {len(failed)}")
    for fname, r in failed:
        print(f"     - {fname}  ({r.get('time', 'N/A')})")

    print(f"  ... 待处理: {len(pending)}")
    for f in pending:
        print(f"     - {f.name}")

    print()

# ============================================================
# 主流程
# ============================================================
def main():
    schedule_mode = "--schedule" in sys.argv or "--daemon" in sys.argv
    show_status_mode = "--status" in sys.argv or "--list" in sys.argv
    force_mode = "--force" in sys.argv

    if show_status_mode:
        show_status()
        return

    if schedule_mode:
        run_schedule(interval=300)
        return

    if len(sys.argv) >= 2 and not sys.argv[1].startswith("--"):
        # 单文件模式（兼容旧用法）
        html_path = Path(sys.argv[1])
        cover_path = Path(sys.argv[2]) if len(sys.argv) > 2 else None

        if not html_path.exists():
            print(f"[ERROR] HTML 文件不存在: {html_path}")
            sys.exit(1)

        print("=" * 60)
        print("  微信公众号文章发布工具（单文件模式）")
        print("=" * 60)

        access_token = get_access_token()
        ok, media_id, error = process_single_file(html_path, access_token, cover_path)

        if ok and cfg.get("auto_publish", False):
            try:
                publish_draft(access_token, media_id)
                print(f"\n[SUCCESS] 文章已发布！")
            except Exception as e:
                print(f"[WARN] 发布失败: {e}")

        if ok:
            print(f"\n[DRAFT] 草稿已保存 (media_id: {media_id})")
        else:
            sys.exit(1)

    else:
        # 默认模式：批量处理 OUTPUT 目录
        print("=" * 60)
        print("  微信公众号文章发布工具（批量模式）")
        print("=" * 60)
        print(f"  扫描目录: {OUTPUT_DIR}")
        print(f"  自动发布: {'是' if cfg.get('auto_publish', False) else '否'}")
        print()

        access_token = get_access_token()
        total, success, failed = process_all_files(access_token=access_token, force=force_mode)

        if failed > 0:
            sys.exit(1)


if __name__ == "__main__":
    main()
