"""
FastAPI backend that wraps Claude Code CLI.
Provides REST + SSE streaming endpoints to interact with claude CLI.
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import AsyncGenerator

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

CLAUDE_BIN: str = "claude"  # on PATH; avoids .CMD spawn issues on Windows
DEFAULT_WORKDIR: str = os.getenv("CLAUDE_WORKDIR", str(Path.home()))
DEFAULT_MODEL: str = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6")
TIMEOUT_SECONDS: int = int(os.getenv("CLAUDE_TIMEOUT", "600"))

# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------

#定义请求体
class PromptRequest(BaseModel):
    """Body for a one-shot prompt."""

    prompt: str = Field(..., description="The prompt to send to Claude Code.")
    workdir: str | None = Field(
        None,
        description="Working directory for Claude Code.  Defaults to the server value.",
    )
    model: str | None = Field(
        None,
        description="Claude model override (e.g. 'claude-opus-4-8').",
    )
    system_prompt: str | None = Field(
        None,
        description="Optional system-level instruction prepended to the prompt.",
    )
    max_tokens: int | None = Field(
        None,
        ge=1,
        description="Maximum tokens for the response.",
    )
    timeout: int | None = Field(
        None,
        ge=5,
        le=600,
        description="Timeout in seconds (5-600).",
    )

#定义响应体
class PromptResponse(BaseModel):
    success: bool
    output: str
    model: str
    workdir: str
    error: str | None = None


class HealthResponse(BaseModel):
    status: str
    claude_bin: str
    claude_available: bool
    default_model: str


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

#创建FASTAPI对象
app = FastAPI(
    title="Claude Code Bridge",
    version="0.1.0",
    docs_url="/docs",
)

#运行前端跨域不同端口
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _shell_quote(text: str) -> str:
    """Quote a string for Windows cmd.exe (double-quote style)."""
    # Escape any embedded double quotes by doubling them, then wrap.
    return '"' + text.replace('"', '""') + '"'


def _build_claude_cmd(
    prompt: str,
    model: str | None,
    system_prompt: str | None,
    max_tokens: int | None,
) -> str:
    """Build a shell command string for `claude -p ...` with proper escaping."""

    parts = [CLAUDE_BIN, "-p", _shell_quote(prompt), "--output-format", "text", "--permission-mode", "bypassPermissions"]

    if system_prompt:
        parts.extend(["--system-prompt", _shell_quote(system_prompt)])

    if model:
        parts.extend(["--model", model])

    if max_tokens:
        parts.extend(["--max-tokens", str(max_tokens)])

#最后拼接效果claude -p "写冒泡排序" --output-format text --permission-mode bypassPermissions --system-prompt "你是Python专家" --model claude-sonnet-4-6 #--max-tokens 1000
    return " ".join(parts)


async def _run_claude(
    cmd: str,
    workdir: str,
    timeout: int,
) -> tuple[int, str, str]:
    """Run Claude CLI via shell and return (returncode, stdout, stderr)."""
    process = await asyncio.create_subprocess_shell(
        cmd,
        cwd=workdir,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(
            process.communicate(),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        process.kill()
        await process.wait()
        raise

    return (
        process.returncode or 0,
        stdout.decode("utf-8", errors="replace").strip(),
        stderr.decode("utf-8", errors="replace").strip(),
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Return whether the Claude CLI is reachable."""
    available = False
    try:
        proc = await asyncio.create_subprocess_shell(
            "claude --version",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await asyncio.wait_for(proc.communicate(), timeout=10)
        available = proc.returncode == 0
    except Exception:
        available = False

    return HealthResponse(
        status="ok" if available else "degraded",
        claude_bin=CLAUDE_BIN,
        claude_available=available,
        default_model=DEFAULT_MODEL,
    )

#请求CLAUDECODE接口
@app.post("/prompt", response_model=PromptResponse)
async def prompt(req: PromptRequest):
    """Send a one-shot prompt to Claude Code and return the full response."""
    workdir = req.workdir or DEFAULT_WORKDIR
    model = req.model or DEFAULT_MODEL
    timeout = req.timeout or TIMEOUT_SECONDS

    if not os.path.isdir(workdir):
        raise HTTPException(status_code=400, detail=f"workdir not found: {workdir}")

    cmd = _build_claude_cmd(
        prompt=req.prompt,
        model=model,
        system_prompt=req.system_prompt,
        max_tokens=req.max_tokens,
    )

    try:
        returncode, stdout, stderr = await _run_claude(cmd, workdir, timeout)
    except asyncio.TimeoutError:
        raise HTTPException(
            status_code=504,
            detail=f"Claude Code timed out after {timeout}s",
        )

    if returncode != 0:
        return PromptResponse(
            success=False,
            output=stdout,
            model=model,
            workdir=workdir,
            error=stderr or f"exit code {returncode}",
        )

    return PromptResponse(
        success=True,
        output=stdout,
        model=model,
        workdir=workdir,
    )


@app.post("/prompt/stream")
async def prompt_stream(req: PromptRequest):
    """Send a prompt and stream the response line-by-line via SSE."""

    workdir = req.workdir or DEFAULT_WORKDIR
    model = req.model or DEFAULT_MODEL
    timeout = req.timeout or TIMEOUT_SECONDS

    if not os.path.isdir(workdir):
        raise HTTPException(status_code=400, detail=f"workdir not found: {workdir}")

    cmd = _build_claude_cmd(
        prompt=req.prompt,
        model=model,
        system_prompt=req.system_prompt,
        max_tokens=req.max_tokens,
    )

    async def event_stream() -> AsyncGenerator[str, None]:
        process = await asyncio.create_subprocess_shell(
            cmd,
            cwd=workdir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            # Stream stdout line by line
            assert process.stdout is not None
            while True:
                line = await asyncio.wait_for(
                    process.stdout.readline(),
                    timeout=timeout,
                )
                if not line:
                    break
                decoded = line.decode("utf-8", errors="replace").rstrip()
                yield f"data: {json.dumps({'chunk': decoded})}\n\n"

            # Ensure the process finishes and grab stderr for errors
            await process.wait()

            if process.returncode != 0 and process.stderr is not None:
                stderr = (await process.stderr.read()).decode("utf-8", errors="replace")
                yield f"data: {json.dumps({'error': stderr, 'exit_code': process.returncode})}\n\n"

            yield "data: [DONE]\n\n"

        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            yield f"data: {json.dumps({'error': f'timeout after {timeout}s'})}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/prompt")
async def prompt_get(
    q: str = Query(..., description="Prompt text"),
    workdir: str | None = Query(None),
    model: str | None = Query(None),
):
    """Convenience GET endpoint — same as POST /prompt but via query-string."""
    return await prompt(
        PromptRequest(
            prompt=q,
            workdir=workdir,
            model=model,
        )
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=12345,
        reload=False,
        log_level="info",
    )
