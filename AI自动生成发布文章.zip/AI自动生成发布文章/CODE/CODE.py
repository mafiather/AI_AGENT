"""
CODE.py — 定时任务：自动调用 /prompt API，读取AUTO_WRITE作为提示词，
异步请求Claude Code生成文章，并将结果存入MySQL。

工作流程:
1. 从MySQL test.auto_task 读取 interval（分钟）
2. 从 AUTO_WRITE.txt 读取提示词
3. 立即返回SUCCESS，异步调用 /prompt API
4. 成功后将结果写入 auto_task_result 表
"""

import asyncio
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import pymysql
import requests

# ---------------------------------------------------------------------------
# 配置 — 路径 & 数据库
# ---------------------------------------------------------------------------

##！！！！！！数据库信息自己DIY
MYSQL_HOST = ""
MYSQL_PORT = 10086
MYSQL_USER = "root"
MYSQL_PASSWORD = ""          # root 无密码（本地开发环境）
MYSQL_DB = ""

# /prompt API 地址 (main.py 运行端口)
API_URL = "http://localhost:10086/prompt"

BACKEND_DIR=Path(__file__).parent
# 【修改】AUTO_WRITE_PATH 改为可变全局变量，main() 每轮遍历会动态更新
AUTO_WRITE_PATH_DEFAULT = os.path.join(BACKEND_DIR, "INPUT", "AUTO_WRITE.txt")
AUTO_WRITE_PATH = AUTO_WRITE_PATH_DEFAULT  # 运行时可被重新赋值
EXAMPLE_PATH = os.path.join(BACKEND_DIR, "EXAMPLE", "EXAMPLE.html")
OUTPUT_DIR = os.path.join(BACKEND_DIR, "OUTPUT")

# API 调用超时（秒）
API_TIMEOUT = 600

# 【新增】全局数据库连接 — 让其他 def 可以直接复用，避免每次查询都新建连接
db_conn = None


def get_db_connection():
    """【新增】获取或创建全局数据库连接，若连接断开则自动重连。"""
    global db_conn
    if db_conn is None or not db_conn.open:
        db_conn = pymysql.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DB,
            charset="utf8",
        )
        print(f"[DB] 全局数据库连接已建立 / 已重连")
    return db_conn


# ---------------------------------------------------------------------------
# 数据库操作
# ---------------------------------------------------------------------------

def get_interval_from_db() -> int:
    """从 MySQL test.auto_task 读取执行间隔（分钟）。"""
    # 【修改】使用全局数据库连接，不再每次新建连接
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT `interval` FROM auto_task ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        if row and row[0] is not None:
            return int(row[0])
        # 默认 60 分钟
        return 60


def insert_result(file_name: str, file_path: str) -> None:
    """向 auto_task_result 插入成功记录。"""
    # 【修改】使用全局数据库连接，不再每次新建连接
    conn = get_db_connection()
    with conn.cursor() as cursor:
        # 获取当前最大 id
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM auto_task_result")
        next_id = cursor.fetchone()[0]
        cursor.execute(
            "INSERT INTO auto_task_result (id, result, fileName, filePath) "
            "VALUES (%s, %s, %s, %s)",
            (next_id, "success", file_name, file_path),
        )
    conn.commit()


# 【新增】从 ARTICLE_CATA 表查询文章生成提示词的文件路径
def get_article_from_db(category_id: int) -> str:
    """根据 ID 查询 ARTICLE_CATA 表的 CATAGORY_PATH 字段。

    Args:
        category_id: 文章分类ID（范围 1~4）

    Returns:
        CATAGORY_PATH 的值，即生成文章的提示词 txt 文件路径。
        若查询失败则返回默认路径。
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT CATAGORY_PATH FROM ARTICLE_CATA WHERE ID = %s",
                (category_id,),
            )
            row = cursor.fetchone()
            if row and row[0] is not None:
                path = row[0]
                print(f"[DB] 查询 ARTICLE_CATA ID={category_id} -> CATAGORY_PATH={path}")
                return path
            else:
                print(f"[DB] 警告: ARTICLE_CATA 中未找到 ID={category_id} 的记录，使用默认路径")
                return AUTO_WRITE_PATH_DEFAULT
    except Exception as exc:
        print(f"[DB] 查询 ARTICLE_CATA 异常: {exc}，使用默认路径")
        return AUTO_WRITE_PATH_DEFAULT


# ---------------------------------------------------------------------------
# 文件操作
# ---------------------------------------------------------------------------

def read_prompt() -> str:
    """读取 AUTO_WRITE.txt 并结合 EXAMPLE.html 构建完整提示词。"""
    with open(AUTO_WRITE_PATH, "r", encoding="utf-8") as f:
        base_prompt = f.read()

    # 构建精简但完整的提示词
    full_prompt = f"""任务：生成一篇微信公众号风格的完整HTML文章。必须直接输出HTML代码。

基本要求:
{base_prompt}

核心要求：
1. 必须输出完整HTML，从 <!DOCTYPE html> 开始到 </html> 结束
2. 文章风格：微信公众号文章，CSS使用微信绿(#07c160)作为主题色
3. 文章主题：搜索2026年6至7月最新资讯和爆炸新闻，基于搜索到的真实新闻参考撰写
4. 字数不少于1500字，包含3-5个小标题分段
5. 必须包含：标题、发布时间、阅读量、SVG数据图表、引用框(quote-box)、信息卡片(info-card)、标签(tag)、作者卡片(author-card)、二维码占位
6. 禁止输出任何解释说明或代码块标记，只输出纯HTML代码

CSS样式必须包含：
- .article-wrapper (max-width:680px, 居中, 白色背景)
- .article-header, .article-title (22px加粗), .article-meta
- .article-body p (16px, text-indent:2em), h2 (19px, 左侧#07c160色边框)
- .highlight-box (绿色渐变背景, #07c160左边框)
- .quote-box (灰色背景, 引号装饰)
- .info-card (白底卡片, 表格)
- .feature-grid (2列网格)
- .timeline (左侧#07c160圆点时间线)
- .data-row (flex数字展示)
- .tag-row, .tag (#576b95蓝标签)
- .author-card, .qr-section
- 响应式 @media (max-width:480px)
- 文章参考路径: {EXAMPLE_PATH}
"""
    return full_prompt


def get_next_filename() -> str:
    """获取下一个文件名: NEWFILE + 3位数字（从001开始）。"""
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    max_num = 0
    pattern = re.compile(r"^NEWFILE(\d{3})\.html$")
    for entry in os.listdir(OUTPUT_DIR):
        m = pattern.match(entry)
        if m:
            max_num = max(max_num, int(m.group(1)))

    next_num = max_num + 1
    return f"NEWFILE{next_num:03d}.html"


def save_article(content: str, file_name: str) -> str:
    """将文章内容保存到 OUTPUT 目录，返回完整路径。

    对输出进行清理：去除前言、代码块标记、后记等非HTML内容。
    """
    # 清理输出：提取从 <!DOCTYPE html> 到 </html> 之间的内容
    html_start = content.find("<!DOCTYPE html>")
    html_start_alt = content.find("<html")
    if html_start >= 0:
        content = content[html_start:]
    elif html_start_alt >= 0:
        content = content[html_start_alt:]

    # 去除开头的 ```html 或 ``` 代码块标记
    content = content.lstrip()
    if content.startswith("```html"):
        content = content[7:]
    elif content.startswith("```"):
        content = content[3:]
    content = content.lstrip()

    # 截断到 </html> 之后（去除后记说明文字）
    html_end = content.find("</html>")
    if html_end >= 0:
        content = content[: html_end + len("</html>")]

    file_path = os.path.join(OUTPUT_DIR, file_name)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content)
    return file_path


# ---------------------------------------------------------------------------
# API 调用
# ---------------------------------------------------------------------------

async def call_prompt_api(prompt_text: str) -> dict:
    """异步调用 POST /prompt，返回 JSON 响应。"""
    payload = {
        "prompt": prompt_text,
        "timeout": API_TIMEOUT,
    }
    loop = asyncio.get_running_loop()
    response = await loop.run_in_executor(
        None,
        lambda: requests.post(API_URL, json=payload, timeout=API_TIMEOUT + 30),
    )
    return response.json()


# ---------------------------------------------------------------------------
# 核心任务
# ---------------------------------------------------------------------------

async def execute_task() -> bool:
    """执行一次任务：调 /prompt → 保存文章 → 写 DB。

    Returns:
        True 成功, False 失败
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] [READ] 读取提示词...")
    prompt_text = read_prompt()
    print("\n====================完整提示词开始====================")
    print(prompt_text)
    print("====================完整提示词结束====================\n")
    print(f"[{timestamp}] [INFO] 提示词长度: {len(prompt_text)} 字符")

    file_name = get_next_filename()
    print(f"[{timestamp}] [INFO] 目标文件名: {file_name}")

    # 调用 API
    print(f"[{timestamp}] [CALL] 调用 /prompt API (超时: {API_TIMEOUT}s)...")
    try:
        result = await call_prompt_api(prompt_text)
    except Exception as exc:
        print(f"[{timestamp}] [ERROR] API 调用异常: {exc}")
        return False

    if not result.get("success"):
        error = result.get("error", "未知错误")
        print(f"[{timestamp}] [ERROR] API 返回失败: {error}")
        return False

    # 提取 Claude 生成的内容
    output = result.get("output", "")
    if not output.strip():
        print(f"[{timestamp}] [WARN] Claude 返回了空内容")
        return False

    print(f"[{timestamp}] [OK] API 成功，输出长度: {len(output)} 字符")

    # 保存文章
    file_path = save_article(output, file_name)
    print(f"[{timestamp}] [SAVE] 文章已保存: {file_path}")

    # 写 DB 结果
    insert_result(file_name, file_path)
    print(f"[{timestamp}] [DB] 已写入 auto_task_result: result=success, "
          f"fileName={file_name}, filePath={file_path}")

    return True


# ---------------------------------------------------------------------------
# 主循环
# ---------------------------------------------------------------------------

async def main():
    """定时任务主循环。"""
    print("=" * 60)
    print("  CODE.py — MaffettAgent 定时任务启动")
    print(f"  API: {API_URL}")
    print(f"  OUTPUT: {OUTPUT_DIR}")
    print("=" * 60)

    # 【新增】轮次计数器，用于取余循环 ID 1~4，实现每次生成不同文章
    round_counter = 0

    while True:
        try:
            interval_minutes = get_interval_from_db()
            print(f"\n[TIMER] 执行间隔: {interval_minutes} 分钟")

            # 【新增】每轮遍历调用 get_article_from_db 获取不同的 CATAGORY_PATH
            # 使用取余方式循环 ID 1~4，实现每次生成的文章内容都不一样
            global AUTO_WRITE_PATH
            category_id = (round_counter % 4) + 1  # 取余循环: 1, 2, 3, 4, 1, 2, ...
            AUTO_WRITE_PATH = get_article_from_db(category_id)
            print(f"[INFO] 第 {round_counter + 1} 轮，使用分类ID={category_id}，"
                  f"提示词路径={AUTO_WRITE_PATH}")
            round_counter += 1

            # 立即返回 SUCCESS（表示定时任务已触发）
            print("SUCCESS -- 任务已触发，开始异步执行...")

            success = await execute_task()

            if success:
                print(f"[DONE] 本轮完成，等待 {interval_minutes} 分钟后执行下一轮...")
            else:
                print(f"[WARN] 本轮失败，等待 {interval_minutes} 分钟后重试...")

        except Exception as exc:
            print(f"[FATAL] 未预期的异常: {exc}")
            interval_minutes = 5  # 出错时默认 5 分钟后重试

        await asyncio.sleep(interval_minutes * 60)


# ---------------------------------------------------------------------------
# 单次执行模式 (用于测试)
# ---------------------------------------------------------------------------

async def run_once():
    """单次执行模式：只跑一次，用于测试验证。"""
    print("=" * 60)
    print("  CODE.py — 单次测试模式")
    print("=" * 60)

    print("SUCCESS -- 任务已触发，开始异步执行...")
    success = await execute_task()

    if success:
        print("\n[PASS] 测试完成：成功生成 1 篇文章")
    else:
        print("\n[FAIL] 测试失败：未能生成文章")
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--once":
        # 单次执行，用于测试
        asyncio.run(run_once())
    else:
        # 定时循环模式
        asyncio.run(main())
